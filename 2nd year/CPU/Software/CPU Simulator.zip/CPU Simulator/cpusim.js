// Copyright (C) Thorsten Thormaehlen, Marburg, 2013, All rights reserved
// Contact: www.thormae.de

// This software is written for educational (non-commercial) purpose. 
// There is no warranty or other guarantee of fitness for this software, 
// it is provided solely "as is". 

// Version: 1.4

function UIElement(x, y, width, height, type, ref, subref, slotType) {
  this.x = x;
  this.y = y;
  this.x2 = x + width;
  this.y2 = y + height;
  this.type = type; // 0 = switch, 1 = register_up, 2 = register_down, 3 = mux_down, 4 = mux_up, 5 = mcBit
  this.ref = ref;
}

function Bus() {
  this.path = [0.0, 0.0];
  this.state = true;
  this.drawArrow = true;
  this.color = "rgba(0, 0, 0, 1.0)";
}

function Mux() {
  this.position = [0.0, 0.0];
  this.state = 0;
  this.name = "tba";
  this.states = ["state 0", "state 1", "state 2"];
  this.mcIdRange = [0, 0];
  this.color = "#FFD305";
}

function Switch() {
  this.position = [0.0, 0.0];
  this.state = false;
  this.phase = 0;
  this.mcId = 0;
  this.busRefs = new Array();
  this.color = "rgba(0, 0, 0, 1.0)";
}

function MicroCodeBit() {
  this.position = [0.0, 0.0];
  this.state = false;
}

function MicrocodeWord() {
  this.data = new Array();
  this.comment = ""; 
};

function Register() {
  this.position = [0.0, 0.0];
  this.value = 0;
  this.name = "tba";
  this.maxValue = 65536;
  this.bits = 16; // maxValue and bits should match
  this.color = "#5392B5";
}

function Memory () {
  this.ram = new Array();
  this.rom = new Array();
};

function ExportCollection() {
  this.description = "none";
  this.version = -1;
  this.storedComplexity = -1;
  this.storedRegistersContent = -1;
  this.storedPhase = -1;
  this.storedMCWord = -1;
  this.memory = -1;
}

function CpuSimCtrl() {
  this.switches = new Array();
  this.registers = new Array();
  this.registersNeedsUpdate = false;
  this.busArray = new Array();
  this.muxArray = new Array();
  this.microCodeBits = new Array();
  this.mem = new Memory(); 
  this.ramNeedsUpdate = 0; // 0=none; 1=complete, 2=values
  this.romNeedsUpdate = 0; // 0=none; 1=complete, 2=values
  this.complexity = 1;
  var that = this;
  this.phase = 1;
  this.mcnHelper ="NextMCAR=4*MCNext";
          
  this.init = function() {
    this.switches.length = 0;
    this.registers.length = 0;
    this.busArray.length = 0;
    this.muxArray.length = 0;
    this.microCodeBits.length = 0;
    this.mem.ram.length = 0;
    this.mem.rom.length = 0;

    this.phase = 1;

    this.mcnHelper ="NextMCAR=4*MCNext";

    this.ramNeedsUpdate = 1;
    this.romNeedsUpdate = 1;
    this.registersNeedsUpdate = true;

    this.phase = 1;
    var s;
    for (var m = 0; m < 49; m++) {
      var mc = new MicroCodeBit();
      mc.position = [40.0 + m * 16, 520];
      this.microCodeBits.push(mc);
    }

    var m = new Mux;
    m.position = [260.0, 344];
    m.name = "ALU-FC";
    m.mcIdRange = [10, 16];
    m.states = new Array();
    m.states.push("Z=Z (NOP)"); // 0
    m.states.push("Z=\u2212Z");
    m.states.push("Z=X");
    m.states.push("Z=\u2212X");
    m.states.push("Z=Y");
    m.states.push("Z=\u2212Y");
    m.states.push("Z=Y, X\u2194Y");
    m.states.push("Z=X, X\u2194Y");
    m.states.push("Z=X, Y\u2192X"); // 8
    m.states.push("Z=X+1");
    m.states.push("Z=X\u22121");
    m.states.push("Z=X+Y");
    m.states.push("Z=X\u2212Y");
    m.states.push("Z=X mul Y");
    m.states.push("Z=X div Y");
    m.states.push("Z=X mod Y");
    m.states.push("Z=X sal Y"); // 16
    m.states.push("Z=X sar Y");
    m.states.push("Z=X cmpa Y");
    m.states.push("Z=X and Y");
    m.states.push("Z=X nand Y");
    m.states.push("Z=X or Y");
    m.states.push("Z=X nor Y");
    m.states.push("Z=X xor Y");
    m.states.push("Z=X nxor Y"); // 24
    m.states.push("Z=X sll Y");
    m.states.push("Z=X slr Y");
    m.states.push("Z=X cmpl Y");
    m.states.push("X=0");
    m.states.push("X=0xFFFF");
    m.states.push("Y=0");
    m.states.push("Y=0xFFFF");
    for (var t = 0; t < 16; t++) {
      var text = "Z,X=0x" + t.toString(16).toUpperCase();
      m.states.push(text);
    }
    for (var t = 0; t < 16; t++) {
      var text = "Z,Y=0x" + t.toString(16).toUpperCase();
      ;
      m.states.push(text);
    }

    this.muxArray.push(m);

    var r = new Register();
    r.position = [200.0, 300];
    r.name = "X-Register";
    r.color = "#98d4f0";
    this.registers.push(r);

    r = new Register();
    r.position = [340.0, 300];
    r.name = "Y-Register";
    r.color = "#2ba5e5";
    this.registers.push(r);

    r = new Register();
    r.position = [240.0, 375];
    r.name = "Z-Register";
    r.color = "#5E9C63";
    this.registers.push(r);

    r = new Register();
    r.position = [330.0, 375];
    r.name = "Flags";
    r.color = "#E80CA4";
    r.maxValue = 16;
    r.bits = 4;
    r.value = 0x8;
    this.registers.push(r);

    var b = new Bus();
    b.path = [240.0, 40.0, 240.0, 295.0, 240.0, 300.0];
    b.color = "rgba(152, 212, 240, 1.0)";
    b.phase = 1;
    this.busArray.push(b);

    b = new Bus();
    b.path = [380.0, 40.0, 380.0, 295.0, 380.0, 300.0];
    b.color = "rgba(43, 165, 229, 1.0)";
    b.phase = 1;
    this.busArray.push(b);

    b = new Bus();
    b.path = [260.0, 400.0, 260.0, 420.0, 40, 420.0, 40, 40, 40, 35];
    b.color = "#5E9C63";
    b.phase = 3;
    this.busArray.push(b);

    for (var h = 0; h < 8; h++) {
      r = new Register();
      r.position = [100.0, 40.0 + h * 30];
      r.name = "R" + h;
      if (h === 7)
        r.value = 0x7FFF;
      this.registers.push(r);

      s = new Switch();
      s.position = [200.0, 38.0 + h * 30];

      s.mcId = 16 + h;
      this.switches.push(s);

      b = new Bus();
      b.path = [100.0, 46.0 + h * 30, 200, 46.0 + h * 30];
      b.phase = 1;
      b.drawArrow = false;
      this.busArray.push(b);

      b = new Bus();
      b.path = [200.0, 46.0 + h * 30, 235, 46.0 + h * 30, 235, 46.0 + h * 30, 240, 46.0 + h * 30];
      b.phase = 1;
      b.state = false;
      s.busRefs.push(this.busArray.length);
      this.busArray.push(b);

      s = new Switch();
      s.position = [300.0, 50.0 + h * 30];
      s.mcId = 24 + h;
      this.switches.push(s);

      b = new Bus();
      b.path = [100.0, 58.0 + h * 30, 300, 58.0 + h * 30];
      b.phase = 1;
      b.drawArrow = false;
      this.busArray.push(b);

      b = new Bus();
      b.path = [300.0, 58.0 + h * 30, 375, 58.0 + h * 30, 375, 58.0 + h * 30, 380, 58.0 + h * 30];
      b.phase = 1;
      b.state = false;
      s.busRefs.push(this.busArray.length);
      this.busArray.push(b);

      s = new Switch();
      s.position = [60.0, 44.0 + h * 30];
      s.mcId = 32 + h;
      this.switches.push(s);

      b = new Bus();
      b.path = [40.0, 52.0 + h * 30, 60, 52.0 + h * 30];
      b.drawArrow = false;
      b.phase = 3;
      this.busArray.push(b);

      b = new Bus();
      b.path = [60.0, 52.0 + h * 30, 95, 52.0 + h * 30, 100, 52.0 + h * 30];
      b.phase = 3;
      b.state = false;
      s.busRefs.push(this.busArray.length);
      this.busArray.push(b);
    }

    if (this.complexity < 2)
      return;

    for (var l = 0; l < 1024; l++)
      this.mem.ram.push(0);

    r = new Register();
    r.position = [520.0, 40.0];
    r.name = "MAR";
    r.color = "#E19AFF";
    r.maxValue = 1024;
    r.bits = 10;
    this.registers.push(r);

    r = new Register();
    r.position = [520.0, 100.0];
    r.name = "MDR";
    r.color = "#E19AFF";
    this.registers.push(r);


    b = new Bus();
    b.path = [290.0, 400, 290.0, 430.0, 460, 430.0, 460, 40, 460, 35];
    b.color = "#5E9C63";
    b.phase = 3;
    this.busArray.push(b);

    b = new Bus();

    b.path = [450, 40, 450, 420.0, 300.0, 420.0, 300.0, 405, 300.0, 400];
    b.color = "#5E9C63";
    b.phase = 1;
    this.busArray.push(b);

    s = new Switch();
    s.position = [480.0, 44.0];
    s.mcId = 40;
    this.switches.push(s);

    b = new Bus();
    b.path = [460.0, 52.0, 480, 52.0];
    b.drawArrow = false;
    b.phase = 3;
    this.busArray.push(b);

    b = new Bus();
    b.path = [480, 52.0, 515, 52.0, 520, 52.0];
    b.phase = 3;
    b.state = false;
    s.busRefs.push(this.busArray.length);
    this.busArray.push(b);

    s = new Switch();
    s.position = [480.0, 72.0];
    s.mcId = 45;
    this.switches.push(s);

    b = new Bus();
    b.path = [560.0, 60.0, 560.0, 80.0, 496, 80.0];
    b.drawArrow = false;
    b.phase = 1;
    this.busArray.push(b);

    b = new Bus();
    b.path = [496, 80, 455, 80, 450, 80];
    b.phase = 1;
    b.state = false;
    s.busRefs.push(this.busArray.length);
    this.busArray.push(b);

    s = new Switch();
    s.position = [480.0, 104.0];
    s.mcId = 41;
    this.switches.push(s);

    b = new Bus();
    b.path = [460.0, 112.0, 480, 112.0];
    b.drawArrow = false;
    b.phase = 3;
    this.busArray.push(b);

    b = new Bus();
    b.path = [480, 112.0, 515, 112.0, 520, 112.0];
    b.phase = 3;
    b.state = false;
    s.busRefs.push(this.busArray.length);
    this.busArray.push(b);

    s = new Switch();
    s.position = [480.0, 132.0];
    s.mcId = 42;
    this.switches.push(s);

    b = new Bus();
    b.path = [540.0, 110.0, 540.0, 140.0, 496, 140.0];
    b.drawArrow = false;
    b.phase = 1;
    this.busArray.push(b);

    b = new Bus();
    b.path = [496, 140, 455, 140, 450, 140];
    b.phase = 1;
    b.state = false;
    s.busRefs.push(this.busArray.length);
    this.busArray.push(b);

    s = new Switch();
    s.position = [480.0, 156.0];
    s.mcId = 43;
    this.switches.push(s);

    b = new Bus();
    b.path = [560.0, 110.0, 560.0, 164.0, 496, 164.0];
    b.drawArrow = false;
    b.phase = 1;
    this.busArray.push(b);

    b = new Bus();
    b.path = [496, 164, 385, 164, 380, 164];
    b.phase = 1;
    b.state = false;
    s.busRefs.push(this.busArray.length);
    this.busArray.push(b);

    m = new Mux;
    m.position = [530.0, 195];
    m.name = "Mode";
    m.color = "#B8E85F";
    m.mcIdRange = [46, 48];
    m.states = new Array();
    m.states.push("wait"); // 0
    m.states.push("read");
    m.states.push("write");
    m.states.push("wait");
    this.muxArray.push(m);

    m = new Mux;
    m.position = [530.0, 223];
    m.name = "Fmt";
    m.color = "#E19A5C";
    m.mcIdRange = [48, 49];
    m.states = new Array();
    m.states.push("1 Byte"); // 0
    m.states.push("2 Bytes");
    this.muxArray.push(m);

    if (this.complexity < 3)
      return;

    for (var l = 0; l < 256; l++) {
      var word = new MicrocodeWord();
      for (var k = 0; k < 6; k++) {
        word.data.push(0);
        word.comment = "no comment";
      }
      this.mem.rom.push(word);
    }

    r = new Register();
    r.position = [520.0, 465.0];
    r.name = "MCAR";
    r.color = "#F3A7A7";
    r.maxValue = 256;
    r.bits = 8;
    this.registers.push(r);

    if (this.complexity < 4)
      return;

    r = new Register();
    r.position = [520.0, 406.0];
    r.name = "NextMCAR";
    r.color = "#F33030";
    r.maxValue = 256;
    r.bits = 8;
    this.registers.push(r);

    r = new Register();
    r.position = [520.0, 376.0];
    r.name = "CC";
    r.color = "#E80CA4";
    r.maxValue = 16;
    r.bits = 4;
    this.registers.push(r);

    r = new Register();
    r.position = [520.0, 346.0];
    r.name = "MCOP";
    r.color = "#F33030";
    r.maxValue = 256;
    r.bits = 8;
    this.registers.push(r);

    s = new Switch();
    s.position = [480.0, 382.0];
    s.mcId = 9;
    this.switches.push(s);

    b = new Bus();
    b.path = [380.0, 390.0, 480, 390.0];
    b.drawArrow = false;
    b.phase = 2;
    this.busArray.push(b);

    b = new Bus();
    b.path = [480, 390.0, 515, 390.0, 520, 390.0];
    b.phase = 2;
    b.state = false;
    s.busRefs.push(this.busArray.length);
    this.busArray.push(b);

    s = new Switch();
    s.position = [480.0, 180.0];
    s.mcId = 44;
    this.switches.push(s);

    b = new Bus();
    b.path = [580.0, 110.0, 580.0, 187.0, 496, 187.0];
    b.drawArrow = false;
    b.phase = 1;
    this.busArray.push(b);

    b = new Bus();
    b.path = [496, 187.0, 470, 187.0, 470, 360, 515, 360, 520, 360];
    b.phase = 1;
    b.state = false;
    s.busRefs.push(this.busArray.length);
    this.busArray.push(b);

    b = new Bus();
    b.path = [560, 430.0, 560, 460.0, 560, 465.0];
    b.phase = 3;
    this.busArray.push(b);

  };

  this.export = function() {
    var e = new ExportCollection();
    e.version = 13;
    e.storedComplexity = this.complexity;
    e.storedRegistersContent = new Array();
    for (var r = 0; r < this.registers.length; r++) {
      e.storedRegistersContent.push(this.registers[r].value);
    }
    e.storedPhase = this.phase;
    e.storedMCWord = mcBitsToMc();
    e.memory = this.mem;

    return e;
  };

  this.import = function(e) {
    if (e.version !== 13)
      return;
    this.complexity = e.storedComplexity;
    this.init();
    this.phase = e.storedPhase;
    if (e.storedMCWord.length === 6) {
      mcToMcBits(e.storedMCWord);
      mcBitsToSwitches();
      mcBitsToMux();
      mcBitsToMCNHelper();
    }
    this.mem = e.memory;
    if (this.registers.length === e.storedRegistersContent.length) {
      for (var r = 0; r < this.registers.length; r++) {
        this.registers[r].value = e.storedRegistersContent[r];
      }
    }
    return this.complexity;
  };

  this.nextPhase = function() {
    computePhase();
    this.phase++;
    if (this.phase > 3)
      this.phase = 1;
  }; 
  
  this.getMCAR = function() {
    if(this.registers.length > 14) { 
      var r = this.registers[14];
      return r.value;
    }
    return 0;
  };
  
  this.setMCAR = function(mcar) {
    if(this.registers.length >= 14) { 
      var r = this.registers[14];
      r.value = mcar;
      this.romNeedsUpdate = 2;
      
      if(this.mem.rom.length > mcar) {
        mcToMcBits(this.mem.rom[mcar].data);
        mcBitsToSwitches();
        mcBitsToMux();
        mcBitsToMCNHelper();
      }
    }
  };
  
  this.switchClicked = function(switchID) {
    var s = this.switches[switchID];
    this.mcBitClicked(s.mcId);
  };

  this.mcBitClicked = function(mcID) {
    var m = this.microCodeBits[mcID];
    if (m) {
      m.state = !m.state;
      handleExclusiveBits(mcID);
      mcBitsToSwitches();
      mcBitsToMux();
      mcBitsToMCNHelper();
      updateMcWord();
    }
  };

  this.registerUpClicked = function(regID) {
    var r = this.registers[regID];
    if (r.value < r.maxValue - 1) {
      r.value++;
    } else {
      r.value = 0;
    }
    if (regID === 14) {
      this.setMCAR(r.value);
    }
  };

  this.registerDownClicked = function(regID) {
    var r = this.registers[regID];
    if (r.value > 0) {
      r.value--;
    } else {
      r.value = r.maxValue - 1;
    }
    if(regID === 14) {
      this.setMCAR(r.value);
    }
  };

  this.muxDownClicked = function(muxID) {
    var m = this.muxArray[muxID];
    if (m.state > 0) {
      m.state--;
    } else {
      m.state = (m.states.length - 1);
    }
    muxToMcbits(m);

  };

  this.muxUpClicked = function(muxID) {
    var m = this.muxArray[muxID];
    if (m.state < m.states.length - 1) {
      m.state++;
    } else {
      m.state = 0;
    }
    muxToMcbits(m);
  };

 
  function muxToMcbits(m) {
    var val = m.state;
    var cmp = 0x1;
    cmp = cmp << (m.mcIdRange[1] - m.mcIdRange[0]) - 1;
    for (var mc = m.mcIdRange[0]; mc < m.mcIdRange[1]; mc++) {
      var c = that.microCodeBits[mc];
      if ((cmp & val) === cmp) { 
        c.state = true;
      } else {
        c.state = false;
      }
      val = val << 1;
    }
    updateMcWord();
  }
  
  function mcBitsToMux() {
    for (var mm = 0; mm < that.muxArray.length; mm++) {
      var m = that.muxArray[mm];
      var val = 0;
      for (var mc = m.mcIdRange[0]; mc < m.mcIdRange[1]; mc++) {
        val = val << 1;
        var c = that.microCodeBits[mc];
        if (c.state) {
          val = val | 0x1;
        }
      }
      //console.log("mcBitsToMux:" + val);
      m.state = val;
    }
  }
  
  function mcBitsToMCNHelper() {
    if (that.microCodeBits[1].state && that.microCodeBits[2].state) {
      // mc = 11
      if (!that.microCodeBits[3].state && !that.microCodeBits[4].state) {
        //s-mode = 00
        that.mcnHelper = "NextMCAR=4*MCOP";
      } else {
        var mask = 0;
        var b = 0x8;
        for (k = 5; k < 9; k++) {
          if (that.microCodeBits[k].state) {
            mask = mask | b;
          }
          b = b >> 1;
        }
        console.log("mask=" + mask);
        that.mcnHelper = "NextMCAR=(CC & " + mask.toString(2).toUpperCase() +" == 0)? (MCAR+1) : (4*MCOP)";
      }
    } else {
      if (!that.microCodeBits[1].state && !that.microCodeBits[2].state) {
        // mc = 00
        that.mcnHelper = "NextMCAR=4*MCNext";
      }
      if (!that.microCodeBits[1].state && that.microCodeBits[2].state) {
        // mc = 01
        that.mcnHelper = "NextMCAR=MCAR+1+4*MCNext";
      }
      if (that.microCodeBits[1].state && !that.microCodeBits[2].state) {
        // mc = 10
        that.mcnHelper = "NextMCAR=MCAR+1-4*MCNext";
      }
    }
  }
  

  function updateMcWord() {
    var mcar = that.getMCAR();
    if(that.mem.rom.length > mcar) {
      var d = mcBitsToMc();
      that.mem.rom[mcar].data = d;
      that.romNeedsUpdate = 2;
    }
  };

  function handleExclusiveBits(mcID) {
    var mc = that.microCodeBits[mcID];
    if (mc.state) {
      if (mcID >= 16 && mcID < 24) {
        for (m = 16; m < 24; m++) {
          if (m !== mcID) {
            that.microCodeBits[m].state = false;
          }
        }
      }
      if ( (mcID >= 24 && mcID < 32) || mcID === 43) {
        if( mcID !== 43) that.microCodeBits[43].state = false;
        for (m = 24; m < 32; m++) {
          if (m !== mcID) {
            that.microCodeBits[m].state = false;
          }
        }
      }
      if(mcID === 45) {
        that.microCodeBits[42].state = false;
      }
      if(mcID === 42) {
        that.microCodeBits[45].state = false;
      }
    }
  }

  function mcBitsToMc() {
    var data = new Array();
    for (var i = 0; i < 6; i++) {
      var byte = 0;
      for (var m = 1 + i * 8; m < 1 + (i + 1) * 8; m++) {
        byte = byte << 1;
        if (that.microCodeBits[m].state)
          byte |= 0x1;
      }
      data.push(byte);
    }
    var debugStr = "";
    for (var i = 0; i < 6; i++) {
     debugStr += " " + data[i].toString(16);
    }
    console.log("mc=" + debugStr);
    return data;
  }
 
  function mcToMcBits(data) {
    if (data.length < 6)
      return;
    for (var i = 0; i < 6; i++) {
      var byte = data[i];
      for (var m = 0; m < 8; m++) {
        if ((byte & 0x80) === 0x80) {
          that.microCodeBits[1+i*8+m].state = true;
        } else {
          that.microCodeBits[1+i*8+m].state = false;
        }
        byte = byte << 1;
      }
    }
  }

  function mcBitsToSwitches() {
    for (var ss = 0; ss < that.switches.length; ss++) {
      var s = that.switches[ss];
      var m = that.microCodeBits[s.mcId];
      if (m) {
        s.state = m.state;
        var br = s.busRefs;
        for(var b=0; b < br.length; b++) {
          var bus = that.busArray[br[b]];
          bus.state = s.state;
        }
      }
    }
  }
  
  function twokomplement2number(k) {
    if( (k & 0x8000) === 0x8000) {
     k = k-1;
     k = k^0xFFFF; // bitwise complement (16bits)
     k = -k;
    }
    return k;
  }
  
  function number2twokomplement(k) {
    if(k < 0) {
     k = -k;
     k = k^0xFFFF; // bitwise complement (16bits)
     k = k+1;
    }
    return k;
  }
  
  function assignNumberZ(num) {
    var fr = that.registers[3];
    var rz = that.registers[1];
    var val = 0;
    if(num === 0) {
      // is zero
      val = val | 0x8;
    }else{
      if(num > 0) {
         // > zero
        val = val | 0x4;
        // positive overflow?
        if (num > ((rz.maxValue/2) - 1)) {
          val = val | 0x1;
          num = (num & 0x7FFF);
        }
      }else{
        // < zero
        val = val | 0x2;
        //negative overflow?
        var numP = -num;
        if (numP > (rz.maxValue/2)) {
          val = val | 0x1;
          numP = (numP & 0x7FFF);
          num = -numP;
        }
      }
    }
    fr.value = val;
    var k = number2twokomplement(num);
    return k;
  }

  function assignBitsZ(b) {
   
    var fr = that.registers[3];
    var rz = that.registers[2];
    var val = 0;
    b = (b & 0xFFFF);
    if(b=== 0) { 
      // is zero
      val = val | 0x8;
    }else{
     if( (b & 0x8000) === 0x8000) {
         // < zero
         val = val | 0x2;
      }else{
        // > zero
         val = val | 0x4;
      }
    }
    fr.value = val;
    return b;
  }
  
  
  function computePhase() {
    // ---------------- phase 1 --------------------
    if(that.phase===1) {
      // cpu operation
      var rx = that.registers[0];
      //rx.value = Math.floor(Math.random()*(rx.maxValue-1));
      for(var k=0; k < 8; k++){
        if(that.microCodeBits[16+k].state) {
          rx.value = that.registers[k+4].value;
        }
      }
      var ry = that.registers[1];
      //ry.value = Math.floor(Math.random()*(ry.maxValue-1));
      for(var k=0; k < 8; k++){
        if(that.microCodeBits[24+k].state) {
          ry.value = that.registers[k+4].value;
        }
      }
      // ram operation
      if (that.complexity > 1) {
        var mode = that.muxArray[1].state;
        var fmt = that.muxArray[2].state;
        var mar = that.registers[12];
        var mdr = that.registers[13];
        if (mode === 1) {
          // reading in phase 1   
          var add1 = mar.value % that.mem.ram.length;
          var add2 = (mar.value + 1) % that.mem.ram.length;
          if (fmt === 0) {
            mdr.value = that.mem.ram[add1];
          } else {
            mdr.value = (that.mem.ram[add1] << 8) + that.mem.ram[add2];
          }
        }
        var rz = that.registers[2];
        if (that.microCodeBits[45].state) {
          rz.value = mar.value;
        }
        if (that.microCodeBits[42].state) {
          rz.value = mdr.value;
        }
        if (that.microCodeBits[43].state) {
          ry.value = mdr.value;
        }
        
        if(that.complexity > 3) {
          if (that.microCodeBits[44].state) {
            var mcopr = that.registers[17];
            mcopr.value = (mdr.value & 0xFF);
          }
        }
        
      }
    }
    // ---------------- phase 2 --------------------
    if(that.phase===2) {
      var rx = that.registers[0];
      var x = twokomplement2number(rx.value);
      var ry = that.registers[1];
      var y = twokomplement2number(ry.value);
      var rz = that.registers[2];
      var z = twokomplement2number(rz.value);
      var alufc = that.muxArray[0].state;
      
      switch (alufc) {
        case 0:
          rz.value = assignNumberZ(z);
          break;
        case 1:
          rz.value = assignNumberZ(-z);
          break;
        case 2:
          rz.value = assignNumberZ(x);
          break;
        case 3:
          rz.value = assignNumberZ(-x);
          break;
        case 4:
          rz.value = assignNumberZ(y);
          break;
        case 5:
          rz.value = assignNumberZ(-y);
          break;
        case 6:
          {
            rz.value = assignNumberZ(y);
            var tmp = rx.value;
            rx.value = ry.value;
            ry.value = tmp;
          }
          break;
        case 7:
          {
            rz.value = assignNumberZ(x);
            var tmp = rx.value;
            rx.value = ry.value;
            ry.value = tmp;
          }
          break;
        case 8:
            rz.value = assignNumberZ(x);
            rx.value = ry.value;
          break;
        case 9:
            rz.value = assignNumberZ(x+1);
          break;
        case 10:
            rz.value = assignNumberZ(x-1);
          break;
        case 11:
            rz.value = assignNumberZ(x+y);
          break;
        case 12:
            rz.value = assignNumberZ(x-y);
          break;
        case 13:
            rz.value = assignNumberZ(x*y);
          break;
        case 14:
            rz.value = assignNumberZ(Math.floor(x/y));
          break;
        case 15:
            rz.value = assignNumberZ(x%y);
          break;
        case 16:
            rz.value = assignBitsZ(rx.value<<ry.value);
          break;
        case 17:
          {
            var t = rx.value>>ry.value;
            if( (rx.value & 0x8000) === 0x8000 ) {
              t = (t | 0x8000);
            }
            rz.value = assignBitsZ(t);
          }
          break;
        case 18:
          rz.value = assignNumberZ(x-y);
          break;
        case 19:
          rz.value = assignBitsZ( (rx.value&ry.value) );
          break;
        case 20:
          rz.value = assignBitsZ( (rx.value&ry.value)^0xFFFF );
          break;  
        case 21:
          rz.value = assignBitsZ( (rx.value|ry.value) );
          break;
        case 22:
          rz.value = assignBitsZ( (rx.value|ry.value)^0xFFFF );
          break;
        case 23:
          rz.value = assignBitsZ( (rx.value^ry.value) );
          break; 
        case 24:
          rz.value = assignBitsZ( (rx.value^ry.value)^0xFFFF );
          break;  
        case 25:
            rz.value = assignBitsZ(rx.value<<ry.value);
          break;
        case 26:
            rz.value = assignBitsZ(rx.value>>ry.value);
          break;  
        case 27:
            rz.value = assignBitsZ( (rx.value&ry.value)^rx.value );
          break;  
        case 28:
            rx.value = 0;
            break;
        case 29: 
            rx.value = 0xFFFF;
            break;
        case 30:
            ry.value = 0;
            break;
        case 31: 
            ry.value = 0xFFFF;
            break;
        case 32:
        case 33:
        case 34:
        case 35:
        case 36:
        case 37:
        case 38:
        case 39:
        case 40:
        case 41:
        case 42:
        case 43:
        case 44:
        case 45:
        case 46:
        case 47:
          rx.value = alufc - 32;
          rz.value = assignBitsZ(alufc - 32);
          break;
        case 48:
        case 49:
        case 50:
        case 51:
        case 52:
        case 53:
        case 54:
        case 55:
        case 56:
        case 57:
        case 58:
        case 59:
        case 60:
        case 61:
        case 62:
        case 63:
          ry.value = alufc - 48;
          rz.value = assignBitsZ(alufc - 48);
          break;
      }
      if (that.complexity > 3) {
        if (that.microCodeBits[9].state) {
          var frr = that.registers[3];
          var ccr = that.registers[16];
          ccr.value = frr.value;
        }
      }
    }
    // ---------------- phase 3 --------------------
    if (that.phase === 3) {
      var rz = that.registers[2];
      for (var k = 0; k < 8; k++) {
        if (that.microCodeBits[32 + k].state) {
          that.registers[k + 4].value = rz.value;
        }
      }
      // ram operation
      if (that.complexity > 1) {
        var mode = that.muxArray[1].state;
        var fmt = that.muxArray[2].state;
        var mar = that.registers[12];
        var mdr = that.registers[13];

        var rz = that.registers[2];
        if (that.microCodeBits[40].state) {
         mar.value = (rz.value & 0x3FF);
        }
        if (that.microCodeBits[41].state) {
          mdr.value = rz.value;
        }
        
        if (mode === 2) {
          // writing in phase 3
          that.ramNeedsUpdate = 2; 
          var add1 = mar.value % that.mem.ram.length;
          var add2 = (mar.value + 1) % that.mem.ram.length;
          if (fmt === 0) {
            that.mem.ram[add1] = mdr.value & 0xFF;
          } else {
            that.mem.ram[add1] = (mdr.value >> 8) & 0xFF;
            that.mem.ram[add2] = (mdr.value) & 0xFF;
          }
        }
      }
      
      // Next MCAR operation
      if (that.complexity > 3) {
        var mcar = that.registers[14];
        var nextMcar = that.registers[15];
        var ccr = that.registers[16];
        var mcopr = that.registers[17];
        var rz = that.registers[2];
        
        if(that.microCodeBits[1].state && that.microCodeBits[2].state) {
          // mc = 11
          if(!that.microCodeBits[3].state && !that.microCodeBits[4].state) {
            //s-mode = 00
            nextMcar.value = (mcopr.value*4) % 256;
          }else{
            var mask = 0;
            var b = 0x8;
            for(k=5; k < 9; k++) {
              if(that.microCodeBits[k].state) {
                mask = mask | b;
              }
              b = b >> 1;
            }
            console.log("mask="+mask);
            if( (mask & ccr.value) === 0){
              nextMcar.value = (mcar.value + 1) % 256;;
            }else{
              nextMcar.value = (mcopr.value*4) % 256;
            }
          }
        } else {
          var mcn = 0;
          var b = 0x20;
          for (k = 3; k < 9; k++) {
            if (that.microCodeBits[k].state) {
              mcn = mcn | b;
            }
            b = b >> 1;
          }
          console.log("mcn=" + mcn);
            
          if (!that.microCodeBits[1].state && !that.microCodeBits[2].state) {
            // mc = 00
            nextMcar.value = (mcn * 4) % 256;
          }
          if (!that.microCodeBits[1].state && that.microCodeBits[2].state) {
            // mc = 01
            nextMcar.value = (mcar.value + 1 + mcn * 4) % 256;
          }
          if (that.microCodeBits[1].state && !that.microCodeBits[2].state) {
            // mc = 10
            var tt = mcar.value + 1 - mcn * 4;
            if(tt < 0) tt = 0;
            nextMcar.value = (tt) % 256;
          }      
        }
        
        that.setMCAR(nextMcar.value);
      }
    }
  }
}

function CpuSim(parentDivId) {
  var data = new CpuSimCtrl();
  var svg;
  var svgns = "http://www.w3.org/2000/svg";
  var myDiv;
  var divId = parentDivId;
  var hooveredElement = -1;
  var hooveredSwitch = -1;
  var hooveredRegisterUp = -1;
  var hooveredRegisterDown = -1;
  var hooveredMc = -1; 
  var hooveredMuxUp = -1;
  var hooveredMuxDown = -1;
  var ramCellSelected = -1;
  var oldMCAR = -1;
  var timerActive = false;
  var timerSemaphore = true;
  var timerStep = 1;
  var uiElements = new Array();
  var registerOverlay = new Array();
  var ramOverlay = new Array();
  var romOverlay = new Array();
  
  var that = this; 
  var overlays = new Array();

  this.init = function() {

    data.init();

    svg = document.createElementNS(svgns, "svg");
    if (!svg)
      console.log("CpuSim error: can not create a svg element");
    svg.setAttribute('width', 880);
    svg.setAttribute('height', 580);
    svg.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:xlink", "http://www.w3.org/1999/xlink");
    svg.setAttribute('id', parentDivId + "_CpuSim");
    document.body.appendChild(svg);

    myDiv = document.createElement('div');
    if (!myDiv)
      console.log("CpuSim error: can not create a div element");
    
    document.body.appendChild(myDiv);
    myDiv.setAttribute('class', 'cpuSimContainer');
    
    var parent = document.getElementById(divId);
    if (!parent)
      console.log("CpuSim error: can not find an element with the given name: " + divId);
    parent.appendChild(myDiv);
    myDiv.appendChild(svg);
    
    svg.onmousedown = function(event) {
      canvasMouseDown(event);
    };
    svg.onmousemove = function(event) {
      canvasMouseMove(event);
    };
    svg.onmouseup = function(event) {
      canvasMouseUp(event);
    };

    this.update();
  };

  this.nextPhase = function() {
    data.nextPhase();
    this.update();
  };

  this.reset = function() {
    data.init();
    this.update();
  };

  this.setComplexity = function(s) {
    data.complexity = parseInt(s);
    data.init();
    this.update();
  };

  this.export = function() {
    return JSON.stringify(data.export());
  };

  this.import = function(str) {
    var tmp = JSON.parse(str);
    var r = data.import(tmp);
    this.update();
    return r;
  };

  this.importFromFile = function(filename) {
  
    var request = new XMLHttpRequest();
    request.open('GET', filename, false);
    request.send(); //"false" above, will block 

    if (request.status !== 200) {
      alert("can not load file " + filename);
      return -1;
    } else {
      var str = request.responseText;
      var r = this.import(str);
      return r;
    }
    
  };

  this.update = function() {

    // clear svg element
    while (svg.lastChild) {
      svg.removeChild(svg.lastChild);
    }

    uiElements.length = 0;

    // draw status
    drawStatus();
    
    // draw ALU
    if (data.phase === 2) {
      drawALU(true);
    }
    drawALU(false);

    // draw RAM
    if (data.complexity > 1) {
      if (data.phase === 1 && data.muxArray[1].state === 1) {
        drawRAM(true);
      }
      if (data.phase === 3 && data.muxArray[1].state === 2) {
        drawRAM(true);
      }
      drawRAM(false);
    }
    
    if(data.complexity > 2) {
      drawROM(false);
    }
    
    if(data.complexity > 3) {
      if (data.phase === 3) {
         drawMcNext(true);
      }
      drawMcNext(false);
    }
    
    drawRamContent();
    
    drawRomContent();
    
    // draws all bus
    drawBusArray(true);
    drawBusArray(false);
    
    // draw all mux
    drawMuxArray();
    
    // draws all switches
    drawSwitches();
    
    // draws all registers
    drawRegisters();
    drawRegisterContent();
    
    // draw all microcodebits
    drawMicroCodeInfo();
    drawMicroCodeBits();
  };
  
  function drawStatus() {
    var text = document.createElementNS(svgns, 'text');
    text.setAttribute("fill", "#000000");
    text.setAttribute("font-family", "sans-serif");
    text.setAttribute("text-anchor", "left");
    text.setAttribute("font-size", "10pt");
    text.setAttribute("font-weight", "bold");
    text.setAttribute("x", 10);
    text.setAttribute("y", 20);

    if (data.phase === 1) {
      text.textContent = "Next cycle phase: 1 (Fetch)";
    }
    if (data.phase === 2) {
      text.textContent = "Next cycle phase: 2 (Execute)";
    }
    if (data.phase === 3) {
      text.textContent = "Next cycle phase: 3 (Store)";
    }
    svg.appendChild(text);
  }
  
  
  function drawRegisterContent() {
    if(!data.registersNeedsUpdate) return;
    data.registersNeedsUpdate = false;
    registerOverlay.length = 0;
    
    var oldRegisterDiv = document.getElementById(divId+"_registerdiv");
    if(oldRegisterDiv) {
      myDiv.removeChild(oldRegisterDiv);
    }
        
    // re-generate
    var myRamDiv = document.createElement('div');
    myRamDiv.setAttribute('id', divId+"_registerdiv");
    myRamDiv.setAttribute('class', 'registerDiv');
    for (var regID = 0; regID < data.registers.length; regID++) {
      var r = data.registers[regID];
      var myInput = document.createElement('input');
      myInput.setAttribute('class', 'registerEdit');
      myInput.setAttribute('type', 'text');
      myInput.setAttribute('value', addLeadingZero(r.value.toString(16).toUpperCase(), r.bits / 4));
      myInput.setAttribute('style', 'left:' + (r.position[0] + 15) + 'px; top:' + (r.position[1] + 11) + 'px;');
      myInput.setAttribute('data-regid', regID);
      myInput.setAttribute('data-hasFocus','0');
      myInput.onkeypress = function(event) {
        myRegKeyPress(event);
      };
      myInput.onblur = function(event) {
        myRegBlur(event);
      };
      registerOverlay.push(myInput);
      myRamDiv.appendChild(myInput);
    }
    
    myDiv.appendChild(myRamDiv);
 
  } 
 
  function drawRomContent() {
    
    var mcar = data.getMCAR();
    
    if(oldMCAR !== -1) { 
      if(oldMCAR !== mcar) {
        if(data.romNeedsUpdate !== 1) {
          data.romNeedsUpdate = 2;
        }
      }
    }
    oldMCAR = mcar;
    
    if (data.romNeedsUpdate === 0)
      return;

   
 
    if (data.romNeedsUpdate === 2) {
      if (romOverlay.length === data.mem.rom.length * 8) {
        for (var r = 0; r < data.mem.rom.length; r++) { 
          if (r === mcar) {
            romOverlay[r * 8].setAttribute('class', 'romRowSelected');
          } else {
            romOverlay[r * 8].setAttribute('class', 'romRow');
          }
          romOverlay[r * 8].setAttribute('title', data.mem.rom[r].comment);
          for (var j = 0; j < data.mem.rom[r].data.length; j++) {
            romOverlay[r*8+j+1].innerHTML = addLeadingZero(data.mem.rom[r].data[j].toString(16).toUpperCase(), 2);
          }
        }
      }
      data.romNeedsUpdate = 0;
      return;
    }

    var scrollTop = 0;
    // clean up
    var oldRomDiv = document.getElementById(divId + "_romdiv");
    if (oldRomDiv) {
      scrollTop = oldRomDiv.scrollTop;
      console.log("offset" + scrollTop);
      myDiv.removeChild(oldRomDiv);

    }

    romOverlay.length = 0;
    data.romNeedsUpdate = 0;
    
    if(data.mem.rom.length === 0) return;
    // re-generate
    var myRomDiv = document.createElement('div');
    myRomDiv.setAttribute('id', divId+"_romdiv");
    myRomDiv.setAttribute('class', 'romDiv');
     
    var myTable = document.createElement('table');
    myTable.setAttribute('id', divId+"_romtable");
    myTable.setAttribute('class', 'romTable');

   
    for (var i = 0; i < data.mem.rom.length; i++) {
     var myRow = document.createElement('tr');
      
     myRow.setAttribute('title', data.mem.rom[i].comment);
     if(i ===  mcar) {
        myRow.setAttribute('class', 'romRowSelected');
     } else{
       myRow.setAttribute('class', 'romRow');
     }
    
     myRow.setAttribute('data-rid', i);
     myRow.onmousedown = function(event) {
        myRomMouseDown(event);
      };
     romOverlay.push(myRow);
      var myLineNum = document.createElement('td');
      myLineNum.innerHTML = "<b style='color:blue;'>" + addLeadingZero((i).toString(16).toUpperCase(), 2) + ":</b>";
      myLineNum.setAttribute('data-rid', i);
      myRow.appendChild(myLineNum);
      for (var j = 0; j < data.mem.rom[i].data.length; j++) {
        var myCell = document.createElement('td');
        myCell.setAttribute('class', 'romCell');
        myCell.setAttribute('data-rid', i);
        myCell.innerHTML = addLeadingZero(data.mem.rom[i].data[j].toString(16).toUpperCase(), 2);
        myRow.appendChild(myCell);
        romOverlay.push(myCell);
      }
      var myCell = document.createElement('td');
      myCell.setAttribute('class', 'romCommentCell');
      var myInput = document.createElement('input');
      myInput.setAttribute('class', 'romCellEdit');
      myInput.setAttribute('type', 'text');
      myInput.setAttribute('value', data.mem.rom[i].comment);
      myInput.setAttribute('data-rid', i);
      myCell.setAttribute('data-rid', i);
      myCell.appendChild(myInput);

      myInput.onkeypress = function(event) {
        myRomKeyPress(event);
      };
      myInput.onblur = function(event) {
        myRomBlur(event);
      };
      myRow.appendChild(myCell);
      romOverlay.push(myInput);
      
      myRow.appendChild(myCell);
      
      myTable.appendChild(myRow);
    }
    myRomDiv.appendChild(myTable);
    myDiv.appendChild(myRomDiv);
    myRomDiv.scrollTop = scrollTop;
    
    
  }
  
  function drawRamContent() {
    
    if(data.ramNeedsUpdate === 0) return;
    
    if(data.ramNeedsUpdate === 2) {
      if(ramOverlay.length === data.mem.ram.length) {
        for (var r = 0; r < data.mem.ram.length; r++) {
          ramOverlay[r].value = addLeadingZero(data.mem.ram[r].toString(16).toUpperCase(), 2);
        }
      }
      data.ramNeedsUpdate = 0;
      return;
    }
    
    var scrollTop = 0;
    // clean up
    var oldRamDiv = document.getElementById(divId+"_ramdiv");
    if (oldRamDiv) {
      scrollTop = oldRamDiv.scrollTop;
      //console.log("offset" + scrollTop);
      myDiv.removeChild(oldRamDiv);
    }
    
    ramOverlay.length = 0;
    data.ramNeedsUpdate = 0;

    if(data.mem.ram.length === 0) return;
    // re-generate
    var myRamDiv = document.createElement('div');
    myRamDiv.setAttribute('id', divId+"_ramdiv");
    myRamDiv.setAttribute('class', 'ramDiv');
     
    var myTable = document.createElement('table');
    myTable.setAttribute('id', divId+"_ramtable");
    myTable.setAttribute('class', 'ramTable');

   
    for (var i = 0; i < Math.floor(data.mem.ram.length / 8); i++) {
      var myRow = document.createElement('tr');
      var myLineNum = document.createElement('td');
      myLineNum.innerHTML = "<b style='color:blue;'>" + addLeadingZero((i*8).toString(16).toUpperCase(), 4) + ":</b>";
      myRow.appendChild(myLineNum);
      for (var j = 0; j < 8; j++) {
        var myCell = document.createElement('td');
        myCell.setAttribute('class', 'ramCell');
        var con = addLeadingZero(data.mem.ram[i*8+j].toString(16).toUpperCase(), 2);
        myCell.setAttribute('data-cellid', i * 8 + j);

        myCell.innerHTML = "";
        var myInput = document.createElement('input');

        myInput.setAttribute('class', 'ramCellEdit');
        myInput.setAttribute('type', 'text');
        myInput.setAttribute('value', con);
        myInput.setAttribute('data-cellid', i * 8 + j);
        myCell.appendChild(myInput);

        myInput.onkeypress = function(event) {
          myCellKeyPress(event);
        };
        myInput.onblur = function(event) {
          myCellBlur(event);
        };
        ramOverlay.push(myInput);
        myRow.appendChild(myCell);
      }
      myTable.appendChild(myRow);
    }
    myRamDiv.appendChild(myTable);
    myDiv.appendChild(myRamDiv);
    myRamDiv.scrollTop = scrollTop;
  }
  
  function drawBusArray(highlight) {

    var lineWidth = 3;
    if (highlight) {
      lineWidth = 7;
    }
    var fillStyle = "";
    var strokeStyle = "";

    for (var busID in data.busArray) {

      var b = data.busArray[busID];

      if (!highlight || (highlight && b.state && b.phase === data.phase)) {

        var path = b.path;

        if (!highlight) {
          if (!b.state) {
            fillStyle = b.color;
            strokeStyle = b.color;
          } else {
            fillStyle = b.color;
            strokeStyle = b.color;
          }
        } else {
          fillStyle = "rgba(255,0,0,0.5)";
          strokeStyle = "rgba(255,0,0,0.5)";
        }

        var d = "";
        var pathLine; 
         
        for (var p = 0; p < path.length; p += 2) {
          if (p === 0) {
            pathLine = document.createElementNS(svgns, 'path');
            pathLine.setAttribute("stroke-width", lineWidth.toString());
            pathLine.setAttribute("stroke", strokeStyle);
            pathLine.setAttribute("fill", "none");
            d = "";
            d += "M " + path[p] + " " + path[p + 1];
          } else {
            if (p === path.length - 2) {

              // draw arrow
              if (path.length >= 4 && b.drawArrow) {
                pathLine.setAttribute("d", d);
                svg.appendChild(pathLine);
                
                var x0 = path[p - 2];
                var y0 = path[p - 1];
                var x1 = path[p];
                var y1 = path[p + 1];

                var dx = x1 - x0;
                var dy = y1 - y0;

                var arrowPath = document.createElementNS(svgns, 'path');
                arrowPath.setAttribute("stroke", "none");
                arrowPath.setAttribute("fill", fillStyle);

                var dd = "M " + x1 + " " + y1;
                dd += " L " + (x0 - dy) + " " + (y0 + dx);
                dd += " L " + (x0 + dy) + " " + (y0 - dx);
                arrowPath.setAttribute("d", dd);
                svg.appendChild(arrowPath);
              } else {
                d += " L " + path[p] + " " + path[p + 1];
                pathLine.setAttribute("d", d);
                svg.appendChild(pathLine);
              }
            } else {
              d += " L " + path[p] + " " + path[p + 1];
            }
          }
        }
      }
    }
  }
  
  function drawMuxArray() {
    
    var muxHeight = 24;
    for (var muxID = 0; muxID < data.muxArray.length; muxID++) {
      
      var s = data.muxArray[muxID];
      
      var muxWidth = 100;
      if(s.states.length < 5) muxWidth = 80;
      
      var x = s.position[0];
      var y = s.position[1];
      var x2 = s.position[0]+muxWidth;
      var y2 = s.position[1]+ muxHeight;
      var fillStyle = s.color;
      var strokeStyle = "rgba(0, 0, 0, 1.0)";
      
      var path = document.createElementNS(svgns, 'path');
      path.setAttribute("stroke-width", "1");
      path.setAttribute("stroke", strokeStyle);
      path.setAttribute("fill", fillStyle);

      var d = "";
      d += "M " + x + " " + y;
      d += " L " + x2 + " " + y;
      d += " L " + (x2 - 10) + " " + y2;
      d += " L " + (x + 10)  + " " + y2;
      d += " Z";
      path.setAttribute("d", d);
      svg.appendChild(path);

      var dn = new UIElement(s.position[0] + 14, s.position[1], 12, 12, 3, muxID, 0, 0);
      uiElements.push(dn);

      fillStyle = "rgba(128, 128, 128, 1.0)";
      if (muxID === hooveredMuxUp) {
        fillStyle = "rgba(160, 160, 160, 1.0)";
      }
      var dx = dn.x2 - dn.x;
      var dy = dn.y2 - dn.y;
      
      var rect = document.createElementNS(svgns, 'rect');
      rect.setAttribute('x', dn.x);
      rect.setAttribute('y', dn.y);
      rect.setAttribute('height', dx);
      rect.setAttribute('width', dy);
      rect.setAttribute('fill', fillStyle);
      rect.setAttribute('stroke', strokeStyle);
      svg.appendChild(rect);
      
      fillStyle = "rgba(0, 0, 0, 1.0)";
      
      var path = document.createElementNS(svgns, 'path');
      path.setAttribute("stroke-width", "3");
      path.setAttribute("stroke", "none");
      path.setAttribute("fill", fillStyle);

      d = "";
      d += "M " + (dn.x + 2) + " " + (dn.y2 - 2);
      d += " L " + (dn.x2 - 2) + " " + (dn.y2 - 2);
      d += " L " + (dn.x + (dx / 2)) + " " + dn.y;
      d += " Z";
      path.setAttribute("d", d);
      svg.appendChild(path);
      
      dn = new UIElement(s.position[0] + muxWidth - 24, s.position[1], 12, 12, 4, muxID, 0, 0);
      uiElements.push(dn);
      strokeStyle = "rgba(0, 0, 0, 1.0)";
      fillStyle = "rgba(128, 128, 128, 1.0)";

      if (muxID === hooveredMuxDown) {
        fillStyle = "rgba(160, 160, 160, 1.0)";
      }
      dx = dn.x2 - dn.x;
      dy = dn.y2 - dn.y;
      
      rect = document.createElementNS(svgns, 'rect');
      rect.setAttribute('x', dn.x);
      rect.setAttribute('y', dn.y);
      rect.setAttribute('height', dx);
      rect.setAttribute('width', dy);
      rect.setAttribute('fill', fillStyle);
      rect.setAttribute('stroke', strokeStyle);
      svg.appendChild(rect);

      fillStyle = "rgba(0, 0, 0, 1.0)";
      
      path = document.createElementNS(svgns, 'path');
      path.setAttribute("stroke-width", "3");
      path.setAttribute("stroke", "none");
      path.setAttribute("fill", fillStyle);

      d = "";
      d += "M " + (dn.x + 2) + " " + (dn.y + 2);
      d += " L " + (dn.x2 - 2) + " " + (dn.y + 2);
      d += " L " + (dn.x + (dx / 2)) + " " + dn.y2;
      d += " Z";
      path.setAttribute("d", d);
      svg.appendChild(path);

      var text = document.createElementNS(svgns, 'text');
      text.setAttribute("fill", "#000000");
      text.setAttribute("font-family", "sans-serif");
      text.setAttribute("text-anchor", "middle");
      text.setAttribute("font-size", "8pt");
      var posX = x + Math.floor(muxWidth / 2);
      var posY = s.position[1] + (muxHeight / 2) - 1;
      text.setAttribute("x", posX.toString());
      text.setAttribute("y", posY.toString());
      text.textContent = s.name;
      svg.appendChild(text);

      text = document.createElementNS(svgns, 'text');
      text.setAttribute("fill", "#000000");
      text.setAttribute("font-family", "sans-serif");
      text.setAttribute("text-anchor", "middle");
      text.setAttribute("font-size", "8pt");
      posX = x + Math.floor(muxWidth / 2);
      posY = s.position[1] + (muxHeight) - 2.5;
      text.setAttribute("x", posX.toString());
      text.setAttribute("y", posY.toString());
      text.textContent = s.states[s.state];
      svg.appendChild(text);
    }
  }

  function drawSwitches() {

    var switchWidth = 16;
    var switchHeight = 16;
    for (var switchID in data.switches) {
      var s = data.switches[switchID];
      var dn = new UIElement(s.position[0], s.position[1], switchWidth, switchHeight, 0, switchID, 0, 0);
      uiElements.push(dn);

      var dx = dn.x2 - dn.x;
      var dy = dn.y2 - dn.y;
      
      var fillStyle = "#FFFFFF";

      if (!s.state) {
        var rect = document.createElementNS(svgns, 'rect');
        rect.setAttribute('x', dn.x);
        rect.setAttribute('y', dn.y);
        rect.setAttribute('height', dx);
        rect.setAttribute('width', dy);
        rect.setAttribute('fill', fillStyle);
        rect.setAttribute('stroke', "none");
        svg.appendChild(rect);
      }
      
      var strokeStyle = "rgba(0, 0, 0, 1.0)";
      
      var path = document.createElementNS(svgns, 'path');
      path.setAttribute("stroke-width", "2");
      path.setAttribute("stroke", strokeStyle);
      path.setAttribute("fill", "none");
      var d = "";
      d += "M " + dn.x + " " + dn.y;
      d += " L " + dn.x + " " + dn.y2;
      path.setAttribute("d", d);
      svg.appendChild(path);
      
      path = document.createElementNS(svgns, 'path');
      path.setAttribute("stroke-width", "2");
      path.setAttribute("stroke", strokeStyle);
      path.setAttribute("fill", "none");
      d = "";
      d += "M " + dn.x2 + " " + dn.y;
      d += " L " + dn.x2 + " " + dn.y2;
      path.setAttribute("d", d);
      svg.appendChild(path);

      if (switchID === hooveredSwitch) {
        fillStyle = "rgba(0,0,0,0.25)";

        rect = document.createElementNS(svgns, 'rect');
        rect.setAttribute('x', dn.x);
        rect.setAttribute('y', dn.y);
        rect.setAttribute('height', dx);
        rect.setAttribute('width', dy);
        rect.setAttribute('fill', fillStyle);
        rect.setAttribute('stroke', "none");
        svg.appendChild(rect);
      }

      var text = document.createElementNS(svgns, 'text');
      text.setAttribute("fill", "#000000");
      text.setAttribute("font-family", "sans-serif");
      text.setAttribute("text-anchor", "middle");
      text.setAttribute("font-size", "8pt");
      var posX = dn.x + Math.floor(dx / 2);
      var posY = dn.y + Math.floor(dy / 4);
      text.setAttribute("x", posX.toString());
      text.setAttribute("y", posY.toString());
      text.textContent = s.mcId;
      svg.appendChild(text);
    }
  }

  function drawRegisters() {

    var regWidth = 80;
    var regHeight = 24;

    for (var regID=0; regID < data.registers.length; regID++) {
      
      var r = data.registers[regID];
      
      regWidth = 80;
      if(r.bits === 4) regWidth = 50;
      
      var strokeStyle = "rgba(0, 0, 0, 1.0)";
      var fillStyle = r.color;
      
      var rect = document.createElementNS(svgns, 'rect');
      rect.setAttribute('x', r.position[0]);
      rect.setAttribute('y', r.position[1]);
      rect.setAttribute('width', regWidth);
      rect.setAttribute('height', regHeight);
      rect.setAttribute('fill', fillStyle);
      rect.setAttribute('stroke', strokeStyle);
      svg.appendChild(rect);
      
      var dn = new UIElement(r.position[0], r.position[1], 12, 12, 1, regID, 0, 0);
      uiElements.push(dn);

      strokeStyle = "rgba(0, 0, 0, 1.0)";
      fillStyle = "rgba(180, 180, 180, 1.0)";
     
      if (regID === hooveredRegisterUp) {
        fillStyle = "rgba(128, 128, 128, 1.0)";
      }
      var dx = dn.x2 - dn.x;
      var dy = dn.y2 - dn.y;
      
      rect = document.createElementNS(svgns, 'rect');
      rect.setAttribute('x', dn.x);
      rect.setAttribute('y', dn.y);
      rect.setAttribute('height', dx);
      rect.setAttribute('width', dy);
      rect.setAttribute('fill', fillStyle);
      rect.setAttribute('stroke', strokeStyle);
      svg.appendChild(rect);

      fillStyle = "rgba(0, 0, 0, 1.0)";

      var path = document.createElementNS(svgns, 'path');
      path.setAttribute("stroke-width", "1");
      path.setAttribute("stroke", "none");
      path.setAttribute("fill", fillStyle);

      var d = "";
      d += "M " + (dn.x + 2) + " " + (dn.y2 - 2);
      d += " L " + (dn.x2 - 2) + " " + (dn.y2 - 2);
      d += " L " + (dn.x + (dx / 2)) + " " + dn.y;
      path.setAttribute("d", d);
      svg.appendChild(path);

      fillStyle = "rgba(0, 0, 0, 1.0)";
      
      dn = new UIElement(r.position[0], r.position[1] + 12, 12, 12, 2, regID, 0, 0);
      uiElements.push(dn);
      strokeStyle = "rgba(0, 0, 0, 1.0)";
     
      fillStyle = "rgba(180, 180, 180, 1.0)";
      if (regID === hooveredRegisterDown) {
         fillStyle = "rgba(128, 128, 128, 1.0)";
      }
      dx = dn.x2 - dn.x;
      dy = dn.y2 - dn.y;
      
      rect = document.createElementNS(svgns, 'rect');
      rect.setAttribute('x', dn.x);
      rect.setAttribute('y', dn.y);
      rect.setAttribute('height', dx);
      rect.setAttribute('width', dy);
      rect.setAttribute('fill', fillStyle);
      rect.setAttribute('stroke', strokeStyle);
      svg.appendChild(rect);
      
      fillStyle = "rgba(0, 0, 0, 1.0)";
      
      path = document.createElementNS(svgns, 'path');
      path.setAttribute("stroke-width", "1");
      path.setAttribute("stroke", "none");
      path.setAttribute("fill", fillStyle);

      var d = "";
      d += "M " + (dn.x + 2) + " " + (dn.y + 2);
      d += " L " + (dn.x2 - 2) + " " + (dn.y + 2);
      d += " L " + (dn.x + (dx / 2)) + " " + dn.y2;
      path.setAttribute("d", d);
      svg.appendChild(path);

      var text = document.createElementNS(svgns, 'text');
      text.setAttribute("fill", "#000000");
      text.setAttribute("font-family", "sans-serif");
      text.setAttribute("text-anchor", "left");
      text.setAttribute("font-size", "8pt");
      var posX = r.position[0] + 15;
      var posY = r.position[1] + 10;
      text.setAttribute("x", posX.toString());
      text.setAttribute("y", posY.toString());
      text.textContent = r.name;
      svg.appendChild(text);
      
      if(regID < registerOverlay.length) {
        registerOverlay[regID].value = addLeadingZero(r.value.toString(16).toUpperCase(), r.bits/4);
      }
    }
  }

  function addLeadingZero(str, length) {
    while(str.length < length) {
      str = "0" + str;
    }
    return str;
  }

  function drawMicroCodeBits() {

    var mcWidth = 16;
    var mcHeight = 32;
    for (var mcID = 1; mcID < data.microCodeBits.length; mcID++) {
      var s = data.microCodeBits[mcID];
      var dn = new UIElement(s.position[0], s.position[1], mcWidth, mcHeight, 5, mcID, 0, 0);
      uiElements.push(dn);
      var dx = dn.x2 - dn.x;
      var dy = dn.y2 - dn.y;

      var fillStyle = "#FFFFFF";
      var strokeStyle = "rgba(0, 0, 0, 1.0)";
            
      var rect = document.createElementNS(svgns, 'rect');
      rect.setAttribute('x', dn.x);
      rect.setAttribute('y', dn.y);
      rect.setAttribute('width', dx);
      rect.setAttribute('height', dy);
      rect.setAttribute('fill', fillStyle);
      rect.setAttribute('stroke', "none");
      svg.appendChild(rect);

      if (s.state) {    
        fillStyle = "#65A669";
      } else {
        fillStyle = "#808080";
      }

      if (mcID === hooveredMc) {
        if (s.state) {
          fillStyle = "#85DB8B";
        } else {
          fillStyle = "#a0a0a0";
        }
      }

      rect = document.createElementNS(svgns, 'rect');
      rect.setAttribute('x', dn.x);
      rect.setAttribute('y', dn.y);
      rect.setAttribute('width', dx);
      rect.setAttribute('height', dy / 2);
      rect.setAttribute('fill', fillStyle);
      rect.setAttribute('stroke', "none");
      svg.appendChild(rect);

      rect = document.createElementNS(svgns, 'rect');
      rect.setAttribute('x', dn.x);
      rect.setAttribute('y', dn.y);
      rect.setAttribute('width', dx);
      rect.setAttribute('height', dy);
      rect.setAttribute('fill', "none");
      rect.setAttribute('stroke', strokeStyle);
      svg.appendChild(rect);
      
      fillStyle = "rgba(255, 255, 255, 1.0)";
      
      var text = document.createElementNS(svgns, 'text');
      text.setAttribute("fill", fillStyle);
      text.setAttribute("font-family", "sans-serif");
      text.setAttribute("text-anchor", "middle");
      text.setAttribute("font-size", "8pt");
      var posX = dn.x + Math.floor(dx / 2);
      var posY = dn.y2 - Math.floor(dy / 2) - 4;
      text.setAttribute("x", posX.toString());
      text.setAttribute("y", posY.toString());
      text.textContent = mcID.toString();
      svg.appendChild(text);

      var textContent = "0";
      if (s.state) {
        textContent = "1";
      }
      
      fillStyle = "rgba(0, 0, 0, 1.0)";
      
      text = document.createElementNS(svgns, 'text');
      text.setAttribute("fill", fillStyle);
      text.setAttribute("font-family", "sans-serif");
      text.setAttribute("text-anchor", "middle");
      text.setAttribute("font-size", "8pt");
      var posX = dn.x + Math.floor(dx / 2);
      var posY = dn.y2 - 4;
      text.setAttribute("x", posX.toString());
      text.setAttribute("y", posY.toString());
      text.textContent = textContent;
      svg.appendChild(text);
    }
  }

  function drawMicroCodeInfoLabel(rectColor, rectX, rectY, rectWidth, rectHeight, textColor, textAlign, textValue, textX, textY) {
    
    var rect = document.createElementNS(svgns, 'rect');
    rect.setAttribute('x', rectX);
    rect.setAttribute('y', rectY);
    rect.setAttribute('width', rectWidth);
    rect.setAttribute('height', rectHeight);
    rect.setAttribute('fill', rectColor);
    rect.setAttribute('stroke', "none");
    svg.appendChild(rect);
    
    var text = document.createElementNS(svgns, 'text');
    text.setAttribute("fill", textColor);
    text.setAttribute("font-family", "sans-serif");
    text.setAttribute("text-anchor", textAlign);
    text.setAttribute("font-size", "8pt");
    text.setAttribute("x", textX.toString());
    text.setAttribute("y", textY.toString());
    text.textContent = textValue.toString();
    svg.appendChild(text);
  }
  
  function drawMicroCodeInfo() {
    
    drawMicroCodeInfoLabel("#FFFFFF", 56, 503, 16 * 8, 16, "#000000", 'left', "Microcode", 56, 517);
    drawMicroCodeInfoLabel("#98d4f0", 40+16*16, 552, 16 * 8, 16, "#000000", 'middle', "X-Bus", 40 + 20 * 16, 564);
    drawMicroCodeInfoLabel("#2ba5e5", 40 + 24 * 16, 552, 16 * 8, 16, "#000000", 'middle', "Y-Bus", 40 + 28 * 16, 564);
    drawMicroCodeInfoLabel("#5E9C63", 40 + 32 * 16, 552, 16 * 8, 16, "#000000", 'middle', "Z-Bus", 40 + 36 * 16, 564);
    drawMicroCodeInfoLabel("#FFD305", 40 + 10 * 16, 552, 16 * 6, 16, "#000000", 'middle', "ALU-FC", 40 + 13 * 16, 564);

    if(data.complexity < 2) return; 
    
    drawMicroCodeInfoLabel("#E19AFF", 40 + 40 * 16, 552, 16 * 6, 16, "#000000", 'middle', "I/O RAM ", 40 + 43 * 16, 564);  
    drawMicroCodeInfoLabel("#B8E85F", 40 + 46 * 16, 552, 16 * 2, 16, "#000000", 'middle', "Mode", 40 + 47 * 16, 564);  
    drawMicroCodeInfoLabel("#E19A5C", 40 + 48 * 16, 552, 18, 16, "#000000", 'left', "Fmt", 40 + 48 * 16, 564);  
    
    if(data.complexity < 4) return;
    
    drawMicroCodeInfoLabel("#E80CA4", 40 + 9 * 16, 552, 16 * 1, 16, "#000000", 'left', "CC", 40 + 9 * 16, 564);
    drawMicroCodeInfoLabel("#F33030", 40 + 3 * 16, 552, 16 * 6, 16, "#000000", 'middle', "MCNext", 40 + 6 * 16, 564);
    drawMicroCodeInfoLabel("#713830", 40 + 1 * 16, 552, 16 * 2, 16, "#000000", 'middle', "MC", 40 + 2 * 16, 564); 

    drawMicroCodeInfoLabel("#FFFFFF", 56, 568, 16 * 8, 16, "#909090", 'left', data.mcnHelper, 56, 578);
  }
  
  function drawALU(highlight) {
    if (!highlight) {
      var text = document.createElementNS(svgns, 'text');
      text.setAttribute("fill", "#000000");
      text.setAttribute("font-family", "sans-serif");
      text.setAttribute("text-anchor", "left");
      text.setAttribute("font-size", "8pt");
      text.setAttribute("x", 180);
      text.setAttribute("y", 297);
      text.textContent = "ALU";
      svg.appendChild(text);
    }
    
    var strokeStyle = '#808080';
    var lineWidth = 2;
    var fillStyle = '#f0f0f0'; 
    if (highlight) {
      strokeStyle = "rgba(255,0,0,0.5)";
      lineWidth = 5;
      fillStyle = "none";
    }
    
    var path = document.createElementNS(svgns, 'path');
    path.setAttribute("stroke-width", lineWidth.toString());
    path.setAttribute("stroke", strokeStyle);
    path.setAttribute("fill", fillStyle);
    
    var d = "";
    d += "M 180 300";
    d += " L 290 300";
    d += " L 310 340";
    d += " L 330 300";
    d += " L 440 300";
    d += " L 380 400";
    d += " L 240 400";
    d += " Z";
    path.setAttribute("d", d);
    svg.appendChild(path);
  }

  function drawRAM(highlight) {
    if (!highlight) {
      var text = document.createElementNS(svgns, 'text');
      text.setAttribute("fill", "#000000");
      text.setAttribute("font-family", "sans-serif");
      text.setAttribute("text-anchor", "left");
      text.setAttribute("font-size", "8pt");
      text.setAttribute("x", 520);
      text.setAttribute("y", 27);
      text.textContent = "RAM";
      svg.appendChild(text);
    }
    
    var strokeStyle = '#808080';
    var lineWidth = 2;
    var fillStyle = '#f0f0f0'; 
    if (highlight) {
      strokeStyle = "rgba(255,0,0,0.5)";
      lineWidth = 5;
      fillStyle = "none";
    }
    
    var path = document.createElementNS(svgns, 'path');
    path.setAttribute("stroke-width", lineWidth.toString());
    path.setAttribute("stroke", strokeStyle);
    path.setAttribute("fill", fillStyle);
     
    var d = "";
    d += "M 520 30";
    d += " L 872 30";
    d += " L 872 252";
    d += " L 520 252";
    d += " Z";
    path.setAttribute("d", d);
    svg.appendChild(path);
  }

  function drawROM(highlight) {
    if (!highlight) {
      var text = document.createElementNS(svgns, 'text');
      text.setAttribute("fill", "#000000");
      text.setAttribute("font-family", "sans-serif");
      text.setAttribute("text-anchor", "left");
      text.setAttribute("font-size", "8pt");
      text.setAttribute("x", 610);
      text.setAttribute("y", 277);
      text.textContent = "Microcode ROM";
      svg.appendChild(text);
    }
    
    var strokeStyle = '#808080';
    var lineWidth = 2;
    var fillStyle = '#f0f0f0'; 
    if (highlight) {
      strokeStyle = "rgba(255,0,0,0.5)";
      lineWidth = 5;
      fillStyle = "none";
    }
    
    var path = document.createElementNS(svgns, 'path');
    path.setAttribute("stroke-width", lineWidth.toString());
    path.setAttribute("stroke", strokeStyle);
    path.setAttribute("fill", fillStyle);

    var d = "";
    d += "M 610 280";
    d += " L 872 280";
    d += " L 872 502";
    d += " L 520 502";
    d += " L 520 450";
    d += " L 610 450";
    d += " Z";
    path.setAttribute("d", d);
    svg.appendChild(path);
  }

  function drawMcNext(highlight) {
    if (!highlight) {
      var text = document.createElementNS(svgns, 'text');
      text.setAttribute("fill", "#000000");
      text.setAttribute("font-family", "sans-serif");
      text.setAttribute("text-anchor", "left");
      text.setAttribute("font-size", "8pt");
      text.setAttribute("x", 520);
      text.setAttribute("y", 337);
      text.textContent = "MCAR Compute";
      svg.appendChild(text);
    }
    
    var strokeStyle = '#808080';
    var lineWidth = 2;
    var fillStyle = '#f0f0f0'; 
    if (highlight) {
      strokeStyle = "rgba(255,0,0,0.5)";
      lineWidth = 5;
      fillStyle = "none";
    }
    
    var path = document.createElementNS(svgns, 'path');
    path.setAttribute("stroke-width", lineWidth.toString());
    path.setAttribute("stroke", strokeStyle);
    path.setAttribute("fill", fillStyle);

    var d = "";
    d += "M 520 340";
    d += " L 600 340";
    d += " L 600 440";
    d += " L 520 440";
    d += " Z";
    path.setAttribute("d", d);
    svg.appendChild(path);
  }

  function mouseOverElement(pos) {
    var selectedElement = -1;
    for (var n in uiElements) {
      if (uiElements[n].x - 1 < pos.x &&
              uiElements[n].x2 + 1 > pos.x &&
              uiElements[n].y - 1 < pos.y &&
              uiElements[n].y2 + 1 > pos.y)
      {
        selectedElement = n;
      }
    }
    return selectedElement;
  }

  function timerEventFired() {
    //console.log("fired");
    timerSemaphore = true;
    if (timerActive) {
      if (hooveredRegisterUp !== -1) {
        for(k=0;k<timerStep;k++) data.registerUpClicked(hooveredRegisterUp);
      }
      if (hooveredRegisterDown !== -1) {
        for(k=0;k<timerStep;k++) data.registerDownClicked(hooveredRegisterDown);
      }
      if (hooveredMuxDown !== -1) {
        data.muxDownClicked(hooveredMuxDown);
      }
      if (hooveredMuxUp !== -1) {
        data.muxUpClicked(hooveredMuxUp);
      }
      timerStep++;
      that.update();
      window.setTimeout(timerEventFired, 30);
    }
  }

  function canvasMouseDown(event) {
    var pos = getMouse(event);

    // handle selection
    if (!event.altKey && event.which === 1) {
      var selectedElement = mouseOverElement(pos);
      if (selectedElement !== -1) {
        // handle field selection
        if (uiElements[selectedElement].type === 0) {
          var s = uiElements[selectedElement].ref;
          data.switchClicked(s);
        }
        if (uiElements[hooveredElement].type === 1) {
          var r = uiElements[selectedElement].ref;
          data.registerUpClicked(r);
          if (timerSemaphore) {
            timerActive = true;
            timerSemaphore = false;
            window.setTimeout(timerEventFired, 500);
          }
        }
        if (uiElements[hooveredElement].type === 2) {
          var r = uiElements[selectedElement].ref;
          data.registerDownClicked(r);
          if (timerSemaphore) {
            timerActive = true;
            timerSemaphore = false;
            window.setTimeout(timerEventFired, 500);
          }
        }
        if (uiElements[hooveredElement].type === 3) {
          var m = uiElements[selectedElement].ref;
          data.muxUpClicked(m);
          if (timerSemaphore) {
            timerActive = true;
            timerSemaphore = false;
            window.setTimeout(timerEventFired, 500);
          }
        }
        if (uiElements[hooveredElement].type === 4) {
          var m = uiElements[selectedElement].ref;
          data.muxDownClicked(m);
          if (timerSemaphore) {
            timerActive = true;
            timerSemaphore = false;
            window.setTimeout(timerEventFired, 500);
          }
        }
        if (uiElements[hooveredElement].type === 5) {
          var mc = uiElements[selectedElement].ref;
          data.mcBitClicked(mc);
        }
      }
      that.update();
    }
    event.preventDefault();
  }

  function canvasMouseUp(event) {
    timerActive = false;
    timerStep = 1;
  }

  function canvasMouseMove(event) {
    var pos = getMouse(event);

    hooveredSwitch = -1;
    hooveredRegisterUp = -1;
    hooveredRegisterDown = -1;
    hooveredMc = -1;
    hooveredMuxDown = -1;
    hooveredMuxUp = -1;
    var oldHooveredElement = hooveredElement;
    hooveredElement = mouseOverElement(pos);

    if (hooveredElement !== -1) {
      if (uiElements[hooveredElement].type === 0) {
        hooveredSwitch = uiElements[hooveredElement].ref;
      }
      if (uiElements[hooveredElement].type === 1) {
        hooveredRegisterUp = uiElements[hooveredElement].ref;
      }
      if (uiElements[hooveredElement].type === 2) {
        hooveredRegisterDown = uiElements[hooveredElement].ref;
      }
      if (uiElements[hooveredElement].type === 3) {
        hooveredMuxUp = uiElements[hooveredElement].ref;
      }
      if (uiElements[hooveredElement].type === 4) {
        hooveredMuxDown = uiElements[hooveredElement].ref;
      }
      if (uiElements[hooveredElement].type === 5) {
        hooveredMc = uiElements[hooveredElement].ref;
      }
    }
    if (oldHooveredElement !== hooveredElement)
      that.update();
    oldPos = pos;
    event.preventDefault();
  }

  function getMouse(e) {
    var element = document.getElementById(divId);
    var offsetX = 0, offsetY = 0, mx, my;

    // compute the total offset
    if (element.offsetParent !== undefined) {
      do {
        offsetX += element.offsetLeft;
        offsetY += element.offsetTop;
      } while ((element = element.offsetParent));
    }

    mx = e.pageX - offsetX;
    my = e.pageY - offsetY;
    
    console.log(mx + " " + my);
    return {x: mx, y: my};
  }
  
  function getTarget(e) {
    var targ;
    if (e.target) {
      targ = e.target;
    } else { // deal with Microsoft
      if (e.srcElement)
        targ = e.srcElement;
    }
    if (targ.nodeType === 3) { // deal with Safari
      targ = targ.parentNode;
    }
    return targ;
  }
  
  function myCellMouseDown(e) {
    var targ = getTarget(e);
    var i = parseInt(targ.getAttribute('data-cellid'));
    ramCellSelected = i;
    data.ramNeedsUpdate = true;
    that.update();
  }
  
  function myCellBlur(e) {
    var targ = getTarget(e);
    var str = "0x" + targ.value;
    var t = parseInt(str);
    var i = parseInt(targ.getAttribute('data-cellid'));
    if (t >= 0 && t < 256) {
      data.mem.ram[i] = t;
    }
    targ.value = addLeadingZero(data.mem.ram[i].toString(16).toUpperCase(), 2);
  }
  
  function myCellKeyPress(e) {
    if (e.keyCode === 13) {
      var targ = getTarget(e);
      var str = "0x" + targ.value;
      var t = parseInt(str);
      var i = parseInt(targ.getAttribute('data-cellid'));
      if (t >= 0 && t < 256) {
        data.mem.ram[i] = t;
      }
      targ.value = addLeadingZero(data.mem.ram[i].toString(16).toUpperCase(), 2);
      targ.blur();
    }
  }
 
  function myRegBlur(e) {
    var targ = getTarget(e);
    var str = "0x" + targ.value;
    var t = parseInt(str);

    var i = parseInt(targ.getAttribute('data-regid'));
    var r = data.registers[i];
    if (t >= 0 && t < r.maxValue) {
      r.value = t;
      if(i === 14) {
        data.setMCAR(r.value);
      }
    }
    that.update();
  }

  function myRegKeyPress(e) {
    if (e.keyCode === 13) {
      var targ = getTarget(e);
      targ.blur();
    }
  }
  
  function myRomMouseDown(e){
    var targ = getTarget(e);
    var t = targ.getAttribute('data-rid');
    var i = parseInt(t);
    if(i >=0 && i < 256) {
      data.setMCAR(i);
    }else{
      console.log("error data-rid:" + i);
    }
    that.update();
  }
  
  function myRomBlur(e) {
    var targ = getTarget(e);
    var comment = targ.value;
    var i = parseInt(targ.getAttribute('data-rid'));
    if(data.mem.rom.length > i) {
      data.mem.rom[i].comment = comment;
    }
  }

  function myRomKeyPress(e) {
    if (e.keyCode === 13) {
      var targ = getTarget(e);
      targ.blur();
    }
  }
}